# AI Control Tower - native Power BI report template

Prepared locally: 26 November 2026. Design/deployment candidate for customer testing.

## What is included

- Four native editable report pages: IDA Overview, NOC Draft Evidence, Grant
  Pending Rules, and Definitions & Readiness.
- Pale canvas, red branding, six tinted rounded KPI panels, native page
  navigation, native value cards, and two NOC document-evidence charts.
- Existing IDA measures are bound by name. The NOC document measure is separate
  and explicitly draft. Cost, SLA, Responsible AI and unapproved operational
  measures remain pending, not zero.
- A thin report only: no replacement model, copied source records, credentials,
  sample results, calculated measures or changes to existing report/model.
- [Measure map](measure-bindings.json) and
  [deployment script](Deploy-Control-Tower-Template.ps1).

This ZIP is **not a PBIX/PBIT** and cannot be imported with the Power BI service's
ordinary Upload button. Extract it first, then use one of the routes below.

## Route A - current Power BI Desktop

1. Extract the complete ZIP to a local folder.
2. Sign in to the customer tenant in a current Power BI Desktop version that
   supports PBIP/PBIR and definitionProperties version 2.
3. Open [Control Tower.pbip](Control%20Tower.pbip).
   The report references the customer model/workspace from the supplied
   screenshots. Build access to that existing model is required.
4. Validate rendering and fields. Save a separate report copy and publish it
   under a **new name** to the customer workspace.
5. If the model moved or the name/ID changed, update `datasetReference` in
   [definition.pbir](Control%20Tower.Report/definition.pbir) while Desktop is
   closed. Use the actual model connection, not an invented ID. Alternatively
   use Route B, which resolves the IDs by exact workspace/model name.

The live-connected report does not open the shared semantic model for editing.
Do not select options to add a local model or overwrite the existing report.

## Route B - Fabric Report API

An implementation team member can create this layout directly in the service
without manufacturing a PBIX. Requires PowerShell 7, Azure CLI, the appropriate
Power BI license, customer-tenant sign-in, Contributor workspace access and
access to the existing semantic model.

From the extracted folder, run:

```powershell
az login --tenant "<customer-tenant-id>" --allow-no-subscriptions
.\Deploy-Control-Tower-Template.ps1
```

The first run is **read-only preflight**. It must find exactly one
`mufg-control-tower-nonprod` workspace and one `sm_control_tower_ida` model.
If it finds neither, stop and correct the account/access; do not use a demo
workspace instead.

After checking the resolved workspace and model:

```powershell
.\Deploy-Control-Tower-Template.ps1 -Deploy
```

Default new report name: `Control Tower - Native Dashboard Template`.
Use `-WorkspaceName`, `-SemanticModelName` or `-ReportName` only for confirmed
customer names. The script creates a separate report, binds its definition to
the resolved existing model, follows asynchronous creation and reads back the
new item. It refuses to overwrite/delete an existing report. It does not alter
the model, ingest data or trigger data refresh.

No access token is written to disk. HTTP/authentication failures stop execution.
An accepted but timed-out creation must be inspected before another attempt.
Do not bypass customer script-execution policies; use Desktop or the customer's
approved deployment tooling instead.

## Rebind measures on the existing layout

1. Edit the new report and select the native card/chart.
2. Replace its field-well measure with the approved measure from the shared model.
3. Preserve numeric formatting: count display units None and zero decimal
   places; Success Rate one decimal place and percentage model formatting.
4. For a pending tile, use the Selection pane to find the hidden `*_value` card.
   Bind the approved measure, unhide that card and hide the `*_pending` text.
   Update its note and readiness definitions. Hidden slots currently have no
   measure, so they do not return misleading zero/sample values.
5. Grant has no fact table in this report's model yet. Do not bind an IDA measure
   to a Grant slot. Add Grant's approved table/measures to the shared model
   through the separately approved modeling process first.

The NOC charts explicitly filter `draft_document_shape = TRACE`; they are not
run counts. The document card includes both trace and writeback documents.
There is no common agent/date/business-unit slicer: the current facts are not
conformed. Navigation switches pages; it does not filter disconnected facts.

## Acceptance checks before sharing as a finished dashboard

- All four pages render, titles/notes fit, and native navigation changes pages.
- Current saved-snapshot IDA baseline: Business Runs **91**, eligible Success
  Rate **100.0%**, Eligible Runs **78**, Successful Eligible Runs **78**.
- NOC Documents (Draft): **1,922**, displayed without K rounding. Its two
  trace-only charts each reconcile to **1,844** documents.
- No field errors; no unrelated filters; pending tiles remain clearly pending.
- The old IDA/NOC report, model, measures and tables are unchanged.

Local validation covers JSON schemas, layout bounds, bindings and package
integrity, not Power BI rendering or customer-tenant measure evaluation.
The available authenticated Fabric connection could not see the customer
workspace. **No customer deployment or runtime validation is claimed.**
This package is suitable to send to the implementation team for import/testing,
not evidence that a production dashboard is ready.

Official references:
[PBIR report projects](https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-report)
and [Create Report API](https://learn.microsoft.com/en-us/rest/api/fabric/report/items/create-report).
