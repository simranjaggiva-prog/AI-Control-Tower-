#Requires -Version 7.0
[CmdletBinding(SupportsShouldProcess)]
param(
    [string] $WorkspaceName = 'mufg-control-tower-nonprod',
    [string] $SemanticModelName = 'sm_control_tower_ida',
    [string] $ReportName = 'Control Tower - Native Dashboard Template',
    [switch] $Deploy
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$apiRoot = 'https://api.fabric.microsoft.com/v1'
$reportPath = Join-Path $PSScriptRoot 'Control Tower.Report'
if (-not (Test-Path -LiteralPath $reportPath -PathType Container)) {
    throw 'Extract the entire ZIP first. Run this script beside the Control Tower.Report folder.'
}
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    throw 'Azure CLI is required for this deployment route. Alternatively open Control Tower.pbip in current Power BI Desktop.'
}
$tokenText = & az account get-access-token --resource 'https://api.fabric.microsoft.com' --query accessToken --output tsv
if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($tokenText)) {
    throw 'Sign in to the customer tenant with az login --tenant <tenant-id> --allow-no-subscriptions, then run again.'
}
$headers = @{
    Authorization = "Bearer $tokenText"
    'x-ms-fabric-skill' = 'semantic-model-authoring'
}

function Get-FabricCollection([string] $Uri) {
    $items = [System.Collections.Generic.List[object]]::new()
    do {
        $response = Invoke-RestMethod -Uri $Uri -Headers $headers -Method Get
        foreach ($item in $response.value) { $items.Add($item) }
        $nextProperty = $response.PSObject.Properties['continuationUri']
        $Uri = if ($nextProperty -and $nextProperty.Value) { $nextProperty.Value } else { $null }
        if ($Uri -and (-not $Uri.StartsWith("$apiRoot/", [StringComparison]::Ordinal))) {
            throw 'Unexpected pagination host. No credentials were forwarded.'
        }
    } while ($Uri)
    return $items.ToArray()
}

$workspaces = @(Get-FabricCollection "$apiRoot/workspaces" | Where-Object { $_.displayName -ceq $WorkspaceName })
if ($workspaces.Count -ne 1) {
    throw "Expected exactly one accessible workspace named '$WorkspaceName'; found $($workspaces.Count). Check tenant and access."
}
$workspaceId = $workspaces[0].id
$models = @(Get-FabricCollection "$apiRoot/workspaces/$workspaceId/items?type=SemanticModel" |
    Where-Object { $_.displayName -ceq $SemanticModelName })
if ($models.Count -ne 1) {
    throw "Expected exactly one semantic model named '$SemanticModelName'; found $($models.Count). No report created."
}
$modelId = $models[0].id
Write-Host "Resolved workspace: $WorkspaceName ($workspaceId)"
Write-Host "Resolved model: $SemanticModelName ($modelId)"
if (-not $Deploy) {
    Write-Host 'Read-only preflight passed. Add -Deploy to create a separate report; nothing has been uploaded.'
    return
}
$duplicates = @(Get-FabricCollection "$apiRoot/workspaces/$workspaceId/items?type=Report" |
    Where-Object { $_.displayName -ceq $ReportName })
if ($duplicates.Count -ne 0) {
    throw "A report named '$ReportName' already exists. It will not be overwritten or deleted. Choose a different -ReportName."
}
if (-not $PSCmdlet.ShouldProcess("$WorkspaceName / $ReportName", 'Create new report connected to the existing model')) {
    return
}
$parts = foreach ($file in Get-ChildItem -LiteralPath $reportPath -File -Recurse) {
    $relative = [IO.Path]::GetRelativePath($reportPath, $file.FullName).Replace('\', '/')
    if ($relative -ne 'definition.pbir' -and
        -not $relative.StartsWith('definition/') -and
        -not $relative.StartsWith('StaticResources/')) {
        continue
    }
    if ($relative -eq 'definition.pbir') {
        $definition = Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json
        $definition.datasetReference.byConnection.connectionString = "semanticmodelid=$modelId"
        $bytes = [Text.Encoding]::UTF8.GetBytes(($definition | ConvertTo-Json -Depth 100))
    } else {
        $bytes = [IO.File]::ReadAllBytes($file.FullName)
    }
    @{
        path = $relative
        payloadType = 'InlineBase64'
        payload = [Convert]::ToBase64String($bytes)
    }
}
$body = @{
    displayName = $ReportName
    description = 'Native editable Control Tower layout. IDA operational measures; NOC draft document evidence; Grant pending rules.'
    definition = @{ parts = @($parts) }
} | ConvertTo-Json -Depth 100
$response = Invoke-WebRequest -Uri "$apiRoot/workspaces/$workspaceId/reports" -Headers $headers `
    -Method Post -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body))
if ($response.StatusCode -eq 202) {
    $operationUri = [string] $response.Headers.Location[0]
    if (-not $operationUri.StartsWith("$apiRoot/operations/", [StringComparison]::Ordinal)) {
        throw 'Creation accepted but operation location is unexpected. Inspect workspace before rerunning.'
    }
    $deadline = [DateTime]::UtcNow.AddMinutes(10)
    $retryAfter = if ($response.Headers.ContainsKey('Retry-After')) {
        [int] $response.Headers['Retry-After'][0]
    } else { 5 }
    do {
        if ([DateTime]::UtcNow.AddSeconds($retryAfter) -ge $deadline) {
            throw "Timed out waiting for accepted creation. Inspect operation $operationUri and workspace before rerunning."
        }
        Start-Sleep -Seconds ([Math]::Max(1, $retryAfter))
        $stateResponse = Invoke-WebRequest -Uri $operationUri -Headers $headers -Method Get
        $state = $stateResponse.Content | ConvertFrom-Json
        if ($state.status -in @('Failed', 'Cancelled')) {
            throw "Report creation $($state.status): $($state | ConvertTo-Json -Depth 20 -Compress)"
        }
        if ($state.status -notin @('NotStarted', 'Running', 'Succeeded')) {
            throw "Unexpected creation status '$($state.status)'. Inspect workspace before rerunning."
        }
        $retryAfter = if ($stateResponse.Headers.ContainsKey('Retry-After')) {
            [int] $stateResponse.Headers['Retry-After'][0]
        } else { 5 }
    } while ($state.status -ne 'Succeeded')
    $created = Invoke-RestMethod -Uri "$operationUri/result" -Headers $headers -Method Get
} elseif ($response.StatusCode -eq 201) {
    $created = $response.Content | ConvertFrom-Json
} else {
    throw "Unexpected HTTP status $($response.StatusCode). Inspect workspace before rerunning; no automatic resubmission."
}
$readback = Invoke-RestMethod -Uri "$apiRoot/workspaces/$workspaceId/items/$($created.id)" -Headers $headers -Method Get
if ($readback.displayName -cne $ReportName -or $readback.type -ne 'Report') {
    throw 'Created item readback did not match the requested report.'
}
Write-Host "Report item created and read back: https://app.powerbi.com/groups/$workspaceId/reports/$($created.id)"
Write-Host 'Now open all four pages and validate rendering, navigation, field bindings and values. Item creation is not KPI validation.'
