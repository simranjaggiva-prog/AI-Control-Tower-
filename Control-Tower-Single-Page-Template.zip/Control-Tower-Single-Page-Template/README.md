# Control Tower - single-page template

Prepared locally 27 November 2026. Native PBIR/PBIP candidate for customer testing.

## Design

- One report page, one MUFG logo, one shared header and snapshot notice.
- Four native bookmark-navigation buttons: All, IDA, NOC and Grant, with
  red selected-state styling defined in the included theme.
- All starts visible: approved operational KPI cards explicitly say IDA only,
  plus separate NOC document evidence and Grant readiness. It is not a complete
  all-agent operational aggregate. No document/run summation or averaged rates.
- Business unit and Period rows match the mockup's placement. As explicitly
  selected by the user, these are grey disabled text controls, not working
  slicers. Group/RS/CM are proposed mockup labels, not approved mappings.
  Day/Week/Month/Year/All are disabled until the reporting date, timezone and
  available history are confirmed. Notes state Mapping pending / Saved snapshot.
- Every agent uses the same six-tile IDA layout and lower evidence/definitions
  panels: Business Runs, Cost per outcome, Total cost, Success Rate, Customer
  wait/SLA and Responsible AI.
- NOC operational tiles remain pending. Lower panels show Source documents
  (Draft) and Trace documents (Draft), not run counts. Its earlier evidence
  charts remain in the old report, not this consistent overview.
- Grant uses the same layout with pending rules; no fabricated measures.
- Bookmarks change agent-group visibility only (Data off, Display on).
  They do not filter disconnected facts or modify the semantic model.
- No unbound card slots are included. Pending metrics use text only, fixing
  the blank-card prompts seen after bookmark switching in the previous version.
- Logo is the user's selected PNG supplied on27 November,10:37, preserved
  unchanged with its white background. No watermark removal or image edits.
  This selection is not evidence of formal customer brand approval.

The earlier four-page report is preserved. This package creates a separately
named report: **Control Tower - Single Page Template v4**.
This revision increases title/selector text space, removes empty textbox panels
in favour of native shapes, and sets navigator state colors directly as well as
through the theme. This addresses clipping and black selected buttons visible
in the customer's v3 screenshot; v4 rendering still needs service verification.
It does not include the styling edits manually made to the deployed report;
those were not exported. The shared logo placement is included locally.
No functioning date/business-unit filters, fictional trends, costs, SLA or RAI
results are added. All is a coverage-aware overview, not a fact-table slicer.

## Deploy in Fabric

Extract the whole ZIP. From that extracted folder, in PowerShell 7 with Azure
CLI authenticated through the customer's approved account/device:

```powershell
.\Deploy-Control-Tower-Template.ps1
```

Check that the read-only preflight resolves `mufg-control-tower-nonprod` and
`sm_control_tower_ida`. Then create the separate single-page report:

```powershell
.\Deploy-Control-Tower-Template.ps1 -Deploy
```

The script refuses an existing same-named report. It includes the corrected
scalar/array HTTP header handling. Do not resubmit accepted creation requests
before checking the workspace. No replacement model or ingestion/refresh is
performed. Contributor workspace access and appropriate model permissions are
required. Do not bypass Conditional Access or script-execution restrictions.

Alternatively open [Control Tower.pbip](Control%20Tower.pbip) in current
Power BI Desktop using the customer account, validate and publish as a new report.
The ZIP/PBIP cannot be imported using ordinary Fabric Upload.

## Test before replacing the old report

1. Only one page exists; All is initially visible. Its operational cards are
   labelled IDA only (91 and100.0%), NOC evidence1,922 is shown separately and
   Grant readiness is pending.
2. Click IDA: cards show91 Business Runs,100.0% Success Rate and78/78.
3. Click NOC: the same six-tile geometry shows pending operational metrics.
   Lower evidence cards show1,922 source documents and1,844 trace documents.
   Neither count appears under Business Runs.
4. Click Grant: the same six-tile layout shows pending metrics/rules.
5. Switch All -> IDA -> NOC -> Grant -> All. Logo/header and selector rows
   remain unchanged; only one content group is visible and no views overlap.
6. No empty "Select or drag fields" prompts appear after switching any bookmark.
7. Confirm filter selections are not reset by the display-only bookmarks.
   Business-unit and Period text controls must not change data or pretend to
   filter. Their disabled-state messages must be visible.
8. Save/reopen and check default view, logo fit, button labels and navigation.

In edit mode, bookmark buttons may require Ctrl+click. In reading mode use a
normal click. To edit agent visuals, use View > Selection and expand the
matching content group. Shared header/logo are outside those groups.
Verify the included bookmark theme renders selected state red #CC0025 and text
white; default white/dark text. Correct in the format pane if the service
requires explicit visual formatting.

This version is locally schema/structure-tested, not yet screenshot-verified
in customer Fabric. The earlier multi-page IDA and NOC rendering are verified;
that does not prove this new bookmark interaction works in the service.
Keep the old report until all single-page checks pass.
