# Control Tower - single-page template

Prepared locally 27 November 2026. Native PBIR/PBIP candidate for customer testing.

## Design

- One report page, one MUFG logo, one shared header and snapshot notice.
- Three native bookmark-navigation buttons: IDA, NOC and Grant.
- IDA starts visible with its approved cards and pending future-metric tiles.
- NOC shows its draft document total and the existing two TRACE evidence charts.
- Grant shows pending rules; no fabricated operational measures.
- Bookmarks change agent-group visibility only (Data off, Display on).
  They do not filter disconnected facts or modify the semantic model.
- Existing hidden unbound future-metric card slots remain hidden.
- Logo is the user's selected PNG supplied on27 November,10:37, preserved
  unchanged with its white background. No watermark removal or image edits.
  This selection is not evidence of formal customer brand approval.

The earlier four-page report is preserved. This package creates a separately
named report: **Control Tower - Single Page Template**.
It does not include the styling edits manually made to the deployed report;
those were not exported. The shared logo placement is included locally.
No date/business-unit/All-agent filters, fictional trends, costs, SLA or RAI
results are added.

## Deploy in Fabric

Extract the whole ZIP. From that extracted folder, in PowerShell 7 with Azure
CLI authenticated through the customer's approved account/device:

```powershell
.\Deploy-Control-Tower-Template.ps1
```

Check that the read-only preflight resolves `mufg-control-tower-nonprod` and
`sm_control_tower_ida`. Then create the separate single-page report:

```powershell
.\Deploy-Control-Tower-Template.ps1 -Deploy
```

The script refuses an existing same-named report. It includes the corrected
scalar/array HTTP header handling. Do not resubmit accepted creation requests
before checking the workspace. No replacement model or ingestion/refresh is
performed. Contributor workspace access and appropriate model permissions are
required. Do not bypass Conditional Access or script-execution restrictions.

Alternatively open [Control Tower.pbip](Control%20Tower.pbip) in current
Power BI Desktop using the customer account, validate and publish as a new report.
The ZIP/PBIP cannot be imported using ordinary Fabric Upload.

## Test before replacing the old report

1. Only one page exists; IDA is the initial visible view.
2. IDA cards show 91 Business Runs,100.0% Success Rate and78/78.
3. Click NOC: IDA content disappears; NOC shows1,922 documents. Each TRACE chart
   totals1,844; operational Business Runs/Success Rate remain pending.
4. Click Grant: only Grant pending content shows.
5. Switch back to IDA. Logo/header remain unchanged and no views overlap.
6. Pending unbound card slots never become visible.
7. Confirm filter selections are not reset by the display-only bookmarks.
8. Save/reopen and check default view, logo fit, button labels and navigation.

In edit mode, bookmark buttons may require Ctrl+click. In reading mode use a
normal click. To edit agent visuals, use View > Selection and expand the
matching content group. Shared header/logo are outside those groups.
Format the bookmark navigator's selected state red #CC0025 and text white if
the customer's theme does not already supply the desired selected styling.

This version is locally schema/structure-tested, not yet screenshot-verified
in customer Fabric. The earlier multi-page IDA and NOC rendering are verified;
that does not prove this new bookmark interaction works in the service.
Keep the old report until all single-page checks pass.
